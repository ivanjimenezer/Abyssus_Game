Thanks for downloading this Low Poly Weapon Pack by Kickin' It Studios - especially if you left a donation!

While credit is not required for using these assets, it is definitely appreciated! And if you make something cool, please send me a link as I'd love to check it out.

You may use and modify these assets in any games or projects you like, but you may NOT re-sell them as 3D models.

If you have any issues or questions, or requests for more assets, please either leave a comment on the itch.io page, or you can reach out to me at kickin.it.studios@gmail.com .

And follow me on Instagram and Twitter for more 3D modeling goodness at: https://www.instagram.com/kickin_it_studios/ and https://twitter.com/kickinitstudios

All the best!